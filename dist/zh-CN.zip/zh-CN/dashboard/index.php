<?php

return [
    'search' => '搜寻伺服器...',
    'no_matches' => '找不到符合搜寻条件的伺服器。',
    'cpu_title' => 'CPU',
    'memory_title' => '记忆体',
];
