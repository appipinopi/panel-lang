<?php

return [
    'exceptions' => [
        'delete_self' => '您无法删除您自己的帐号。',
        'user_has_servers' => '无法删除拥有活动伺服器的使用者。请先删除其伺服器后再继续。',
    ],
    'notices' => [
        'account_created' => '帐号已成功建立。',
        'account_updated' => '帐号已成功更新。',
    ],
];
