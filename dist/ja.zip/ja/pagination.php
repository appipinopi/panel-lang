<?php

return [
    'previous' => '&laquo; 前へ',
    'next' => '次へ &raquo;',
];