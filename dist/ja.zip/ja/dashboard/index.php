<?php

return [
    'search' => 'サーバーを検索...',
    'no_matches' => '検索条件に一致するサーバーは見つかりませんでした。',
    'cpu_title' => 'CPU',
    'memory_title' => 'メモリ',
];
